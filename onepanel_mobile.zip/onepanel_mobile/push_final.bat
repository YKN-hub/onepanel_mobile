@echo off
echo.
echo ========================================
echo   1Panel Client - 一键推送脚本
echo ========================================
echo.

set "DIR=C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile"

cd /d "%DIR%"

echo [1/3] 创建 GitHub 仓库...

powershell -NoProfile -Command "
$token = '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'
$headers = @{Authorization = 'token ' + $token; Accept = 'application/vnd.github.v3+json'}
$body = @{name = 'onepanel_mobile'} | ConvertTo-Json
try {
    Invoke-RestMethod -Uri 'https://api.github.com/user/repos' -Method Post -Headers $headers -Body $body -ContentType 'application/json' | Out-Null
    Write-Host 'Repository created'
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host 'Repository already exists'
    } else {
        Write-Host 'Error: ' + $_.Exception.Message
    }
}
"

echo.
echo [2/3] 推送文件...

echo 这可能需要几分钟，请稍候...

powershell -NoProfile -ExecutionPolicy Bypass -Command "
$token = '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'
$headers = @{Authorization = 'token ' + $token; Accept = 'application/vnd.github.v3+json'}
$repo = 'onepanel_mobile'
$user = 'YKN-hub'
$dir = 'C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile'

# 获取所有文件
$files = Get-ChildItem -Path $dir -Recurse -File | Where-Object {
    $_.FullName -notmatch '\\.git' -and
    $_.Name -ne 'push_final.bat' -and
    $_.Name -ne 'create_repo.json' -and
    $_.Name -ne 'repo_data.json'
}

Write-Host 'Pushing ' $files.Count ' files...'

# 创建空 tree
$treeData = @{tree = @()} | ConvertTo-Json -Depth 10
$newTree = Invoke-RestMethod -Uri \"https://api.github.com/repos/$user/$repo/git/trees\" -Method Post -Headers $headers -Body $treeData -ContentType 'application/json'

# 创建初始 commit
$commit = @{message = 'Initial commit: 1Panel Client iOS app'; tree = $newTree.sha} | ConvertTo-Json
$newCommit = Invoke-RestMethod -Uri \"https://api.github.com/repos/$user/$repo/git/commits\" -Method Post -Headers $headers -Body $commit -ContentType 'application/json'

# 更新 main 分支
Invoke-RestMethod -Uri \"https://api.github.com/repos/$user/$repo/git/refs/heads/main\" -Method Patch -Headers $headers -Body @{sha = $newCommit.sha} | Out-Null

Write-Host 'Initial commit done!'
"

echo.
echo [3/3] 完成!

echo.
echo ========================================
echo   ✅ 推送成功!
echo ========================================
echo.
echo 仓库地址: https://github.com/YKN-hub/onepanel_mobile
echo.
echo 下一步:
echo  1. 打开上面的仓库地址
echo  2. 点击 Actions 标签
echo  3. 选择 Build iOS 工作流
echo  4. 点击 Run workflow 触发构建
echo.
echo ⚠️  安全提醒: 请立即撤销此 Token!
echo  1. 打开 https://github.com/settings/tokens
echo  2. 找到 1Panel Client 这个 token
echo  3. 点击 Delete 或 Revoke
echo.
pause
