# 1Panel Client - 完整推送脚本
# 使用 GitHub API 推送所有文件

$ErrorActionPreference = 'Stop'

# 配置
$token = "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"
$username = "YKN-hub"
$repoName = "onepanel_mobile"
$projectDir = "C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile"

# 获取所有文件
$files = Get-ChildItem -Path $projectDir -Recurse -File | Where-Object {
    $_.FullName -notmatch "\.git" -and
    $_.FullName -notmatch "node_modules" -and
    $_.FullName -notmatch "build" -and
    $_.FullName -notmatch "__pycache__" -and
    $_.Name -ne "repo_data.json" -and
    $_.Name -ne "push_via_api.ps1" -and
    $_.Name -ne "push_to_github.bat" -and
    $_.Name -ne "push_to_github.ps1"
}

Write-Host "Found $($files.Count) files"

# 创建 tree
$tree = @()

foreach ($file in $files) {
    $relativePath = $file.FullName.Substring($projectDir.Length + 1).Replace("\", "/")
    
    # 读取文件内容
    $content = Get-Content -Path $file.FullName -Raw -Encoding UTF8
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
    $base64Content = [Convert]::ToBase64String($bytes)
    
    # 创建 blob
    $blobData = @{
        content = $base64Content
        encoding = "base64"
    } | ConvertTo-Json
    
    $headers = @{
        Authorization = "token $token"
        Accept = "application/vnd.github.v3+json"
        "Content-Type" = "application/json"
    }
    
    $blob = Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName/git/blobs" -Method Post -Headers $headers -Body $blobData
    
    $tree += @{
        path = $relativePath
        mode = "100644"
        type = "blob"
        sha = $blob.sha
    }
    
    Write-Host "  Added: $relativePath"
}

# 创建 tree
$treeData = @{
    tree = $tree
} | ConvertTo-Json -Depth 10

$newTree = Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName/git/trees" -Method Post -Headers $headers -Body $treeData -ContentType "application/json"

Write-Host "Tree created: $($newTree.sha)"

# 创建 commit
$commitData = @{
    message = "Initial commit: 1Panel Client iOS app

- 完整仪表盘、服务器、容器、网站、数据库、文件、监控模块
- 60+ 数据模型
- GitHub Actions iOS/Android 构建工作流
- 中英文国际化支持
- 多服务器管理"
    tree = $newTree.sha
} | ConvertTo-Json -Depth 5

$newCommit = Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName/git/commits" -Method Post -Headers $headers -Body $commitData -ContentType "application/json"

Write-Host "Commit created: $($newCommit.sha)"

# 更新引用
$refData = @{
    sha = $newCommit.sha
} | ConvertTo-Json

Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName/git/refs/heads/main" -Method Patch -Headers $headers -Body $refData -ContentType "application/json" | Out-Null

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  ✅ 推送成功!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "📌 仓库地址: https://github.com/$username/$repoName" -ForegroundColor Cyan
Write-Host ""
Write-Host "⚠️  安全提醒: 请立即撤销此 Token!" -ForegroundColor Yellow
