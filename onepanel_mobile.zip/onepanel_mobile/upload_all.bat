@echo off
echo.
echo ========================================
echo   1Panel Client - 上传所有文件
echo ========================================
echo.

set "TOKEN=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"
set "USER=YKN-hub"
set "REPO=onepanel_mobile"
set "DIR=C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile"

echo [1/4] 上传 pubspec.yaml...

powershell -NoProfile -Command "
$token = '%TOKEN%'
$headers = @{Authorization = 'token ' + $token; Accept = 'application/vnd.github.v3+json'}
$content = Get-Content '%DIR%\pubspec.yaml' -Raw -Encoding UTF8
$bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
$b64 = [Convert]::ToBase64String($bytes)
$body = @{message = 'Add pubspec.yaml'; content = $b64} | ConvertTo-Json
Invoke-RestMethod -Uri 'https://api.github.com/repos/%USER%/%REPO%/contents/pubspec.yaml' -Method Put -Headers $headers -Body $body -ContentType 'application/json' | Out-Null
Write-Host '  pubspec.yaml uploaded'
"

echo [2/4] 上传 main.cs...

powershell -NoProfile -Command "
$token = '%TOKEN%'
$headers = @{Authorization = 'token ' + $token; Accept = 'application/vnd.github.v3+json'}
$content = Get-Content '%DIR%\lib\main.dart' -Raw -Encoding UTF8
$bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
$b64 = [Convert]::ToBase64String($bytes)
$body = @{message = 'Add main.dart'; content = $b64} | ConvertTo-Json
Invoke-RestMethod -Uri 'https://api.github.com/repos/%USER%/%REPO%/contents/lib/main.dart' -Method Put -Headers $headers -Body $body -ContentType 'application/json' | Out-Null
Write-Host '  lib/main.dart uploaded'
"

echo [3/4] 上传 iOS 配置...

powershell -NoProfile -Command "
$token = '%TOKEN%'
$headers = @{Authorization = 'token ' + $token; Accept = 'application/vnd.github.v3+json'}
$content = Get-Content '%DIR%\ios\Runner\Info.plist' -Raw -Encoding UTF8
$bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
$b64 = [Convert]::ToBase64String($bytes)
$body = @{message = 'Add Info.plist'; content = $b64} | ConvertTo-Json
Invoke-RestMethod -Uri 'https://api.github.com/repos/%USER%/%REPO%/contents/ios/Runner/Info.plist' -Method Put -Headers $headers -Body $body -ContentType 'application/json' | Out-Null
Write-Host '  ios/Runner/Info.plist uploaded'
"

echo [4/4] 上传其他文件...

powershell -NoProfile -Command "
$token = '%TOKEN%'
$headers = @{Authorization = 'token ' + $token; Accept = 'application/vnd.github.v3+json'}
$repo = '%REPO%'
$user = '%USER%'
$dir = '%DIR%'

# 上传所有文件
$files = Get-ChildItem -Path $dir -Recurse -File | Where-Object {
    $_.FullName -notmatch '\\.git' -and
    $_.Name -ne 'upload_data.json' -and
    $_.Name -ne 'push_*.bat' -and
    $_.Name -ne 'push_*.ps1' -and
    $_.Name -ne 'create_repo.json' -and
    $_.Name -ne 'repo_data.json' -and
    $_.Name -ne 'FINAL_GUIDE.md' -and
    $_.Name -ne 'PUSH_COMPLETE.md' -and
    $_.Name -ne 'PUSH_COMMANDS.md' -and
    $_.Name -ne 'GITHUB_*.md' -and
    $_.Name -ne 'IOS_BUILD_GUIDE.md' -and
    $_.Name -ne 'QUICKSTART.md' -and
    $_.Name -ne 'PROJECT_REPORT.md' -and
    $_.DirectoryName -notmatch '\\.github'
}

foreach ($f in $files) {
    $rel = $f.FullName.Substring($dir.Length + 1).Replace('\', '/')
    $content = Get-Content $f.FullName -Raw -Encoding UTF8
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
    $b64 = [Convert]::ToBase64String($bytes)
    $body = @{message = 'Add ' + $rel; content = $b64} | ConvertTo-Json
    try {
        Invoke-RestMethod -Uri \"https://api.github.com/repos/$user/$repo/contents/$rel\" -Method Put -Headers $headers -Body $body -ContentType 'application/json' | Out-Null
        Write-Host '  ' $rel
    } catch {
        Write-Host '  Error: ' $rel
    }
}

Write-Host 'Done!'
"

echo.
echo ========================================
echo   ✅ 上传完成!
echo ========================================
echo.
echo 仓库地址: https://github.com/%USER%/%REPO%
echo.
echo 下一步:
echo  1. 打开上面的仓库地址
echo  2. 点击 Actions 标签
echo  3. 选择 Build iOS 工作流
echo  4. 点击 Run workflow 触发构建
echo.
echo ⚠️  安全提醒: 请立即撤销此 Token!
echo.
pause
