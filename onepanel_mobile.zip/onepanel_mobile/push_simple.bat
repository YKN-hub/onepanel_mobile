@echo off
chcp 65001 >nul
title 1Panel Client - 推送中...

set TOKEN=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
set USER=YKN-hub
set REPO=onepanel_mobile
set DIR=C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile

echo 正在推送文件，请稍候...

powershell -NoProfile -Command "
$token = '%TOKEN%'
$headers = @{Authorization = 'token ' + $token; Accept = 'application/vnd.github.v3+json'}
$repo = '%REPO%'
$user = '%USER%'
$tree = @()
$files = Get-ChildItem '%DIR%' -Recurse -File | Where-Object { $_.FullName -notmatch '\\.git' -and $_.Name -ne 'push_all.ps1' -and $_.Name -ne 'repo_data.json' -and $_.Name -ne 'push_simple.bat' }
Write-Host 'Files: ' $files.Count
$treeData = @{tree = $tree} | ConvertTo-Json -Depth 10
$newTree = Invoke-RestMethod -Uri \"https://api.github.com/repos/$user/$repo/git/trees\" -Method Post -Headers $headers -Body $treeData -ContentType 'application/json'
$commit = @{message = 'Initial commit'; tree = $newTree.sha} | ConvertTo-Json
$newCommit = Invoke-RestMethod -Uri \"https://api.github.com/repos/$user/$repo/git/commits\" -Method Post -Headers $headers -Body $commit -ContentType 'application/json'
Invoke-RestMethod -Uri \"https://api.github.com/repos/$user/$repo/git/refs/heads/main\" -Method Patch -Headers $headers -Body @{sha = $newCommit.sha} | Out-Null
Write-Host 'Done!'
"

echo.
echo ========================================
echo   推送完成!
echo ========================================
echo.
echo 仓库地址: https://github.com/%USER%/%REPO%
echo.
pause
