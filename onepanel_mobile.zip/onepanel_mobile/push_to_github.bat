@echo off
chcp 65001 >nul
title 1Panel Client - 一键推送脚本
echo.
echo ========================================
echo   1Panel Client - 一键推送脚本
echo ========================================
echo.
echo 用户名: YKN-hub
echo 仓库: onepanel_mobile
echo.
echo ⚠️  安全提醒: 推送完成后请撤销此 Token!
echo.

if not exist "C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile" (
    echo ❌ 错误: 项目目录不存在
    pause
    exit /b 1
)

cd /d "C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile"

echo [1/6] 检查 Git...
git --version >nul 2>nul
if errorlevel 1 (
    echo ❌ 错误: Git 未安装!
    echo 请先安装 Git: https://git-scm.com/download/win
    pause
    exit /b 1
)
echo   ✅ Git 已安装

echo.
echo [2/6] 初始化 Git 仓库...
if not exist ".git" (
    git init >nul 2>nul
    echo   ✅ 已初始化
) else (
    echo   ⏭️  已存在，跳过
)

echo.
echo [3/6] 添加所有文件...
git add -A
echo   ✅ 已添加

echo.
echo [4/6] 提交更改...
git commit -m "Initial commit: 1Panel Client iOS app" >nul 2>nul
echo   ✅ 已提交

echo.
echo [5/6] 添加远程仓库...
git remote | findstr "origin" >nul 2>nul
if errorlevel 1 (
    git remote add origin https://YKN-hub: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@github.com/YKN-hub/onepanel_mobile.git >nul 2>nul
    echo   ✅ 已添加
) else (
    echo   ⏭️  已存在，跳过
)

git branch -M main >nul 2>nul

echo.
echo [6/6] 推送到 GitHub...
echo   正在推送，请稍候...
git push -u origin main

if errorlevel 1 (
    echo.
    echo ❌ 推送失败!
    echo.
    echo 可能的原因:
    echo   1. 仓库已存在，需要先拉取
    echo   2. Token 权限不足
    echo   3. 网络问题
) else (
    echo.
    echo ========================================
    echo   ✅ 推送成功!
    echo ========================================
    echo.
    echo 📌 仓库地址: https://github.com/YKN-hub/onepanel_mobile
    echo.
    echo 🚀 下一步:
    echo   1. 打开 https://github.com/YKN-hub/onepanel_mobile
    echo   2. 点击 Actions 标签
    echo   3. 选择 Build iOS 工作流
    echo   4. 点击 Run workflow 触发构建
    echo.
    echo ⚠️  安全提醒: 请立即撤销此 Token!
    echo   1. 打开 https://github.com/settings/tokens
    echo   2. 找到 1Panel Client 这个 token
    echo   3. 点击 Delete 或 Revoke
    echo.
)

pause
