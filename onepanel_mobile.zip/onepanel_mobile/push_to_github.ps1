# 1Panel Client - 一键推送脚本
# 使用方法: 双击运行此文件

$ErrorActionPreference = 'Stop'
$host.UI.RawUI.WindowTitle = "1Panel Client - 推送脚本"

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  1Panel Client - 一键推送脚本" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "用户名: YKN-hub" -ForegroundColor Cyan
Write-Host "仓库: onepanel_mobile" -ForegroundColor Cyan
Write-Host ""
Write-Host "⚠️  安全提醒: 推送完成后请撤销此 Token!" -ForegroundColor Yellow
Write-Host ""

$projectDir = "C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile"

if (-not (Test-Path $projectDir)) {
    Write-Host "❌ 错误: 项目目录不存在" -ForegroundColor Red
    Pause
    exit 1
}

Set-Location $projectDir

Write-Host "[1/6] 检查 Git..." -ForegroundColor White
try {
    git --version 2>&1 | Out-Null
    Write-Host "  ✅ Git 已安装" -ForegroundColor Green
} catch {
    Write-Host "❌ 错误: Git 未安装!" -ForegroundColor Red
    Write-Host "请先安装 Git: https://git-scm.com/download/win" -ForegroundColor Red
    Pause
    exit 1
}

Write-Host "[2/6] 初始化 Git 仓库..." -ForegroundColor White
if (-not (Test-Path ".git")) {
    git init | Out-Null
    Write-Host "  ✅ 已初始化" -ForegroundColor Green
} else {
    Write-Host "  ⏭️  已存在，跳过" -ForegroundColor Gray
}

Write-Host "[3/6] 添加所有文件..." -ForegroundColor White
git add -A
Write-Host "  ✅ 已添加" -ForegroundColor Green

Write-Host "[4/6] 提交更改..." -ForegroundColor White
git commit -m "Initial commit: 1Panel Client iOS app`n`n- 完整仪表盘、服务器、容器、网站、数据库、文件、监控模块`n- 60+ 数据模型`n- GitHub Actions iOS/Android 构建工作流`n- 中英文国际化支持`n- 多服务器管理" 2>&1 | Out-Null
Write-Host "  ✅ 已提交" -ForegroundColor Green

Write-Host "[5/6] 添加远程仓库..." -ForegroundColor White
$remotes = git remote
if ($remotes -notcontains "origin") {
    git remote add origin https://YKN-hub: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@github.com/YKN-hub/onepanel_mobile.git 2>&1 | Out-Null
    Write-Host "  ✅ 已添加" -ForegroundColor Green
} else {
    Write-Host "  ⏭️  已存在，跳过" -ForegroundColor Gray
}

git branch -M main | Out-Null

Write-Host "[6/6] 推送到 GitHub..." -ForegroundColor White
Write-Host "  正在推送，请稍候..." -ForegroundColor Yellow

git push -u origin main 2>&1

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  ✅ 推送成功!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "📌 仓库地址: https://github.com/YKN-hub/onepanel_mobile" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "🚀 下一步:" -ForegroundColor White
    Write-Host "  1. 打开 https://github.com/YKN-hub/onepanel_mobile" -ForegroundColor Gray
    Write-Host "  2. 点击 Actions 标签" -ForegroundColor Gray
    Write-Host "  3. 选择 Build iOS 工作流" -ForegroundColor Gray
    Write-Host "  4. 点击 Run workflow 触发构建" -ForegroundColor Gray
    Write-Host ""
    Write-Host "⚠️  安全提醒: 请立即撤销此 Token!" -ForegroundColor Yellow
    Write-Host "  1. 打开 https://github.com/settings/tokens" -ForegroundColor Gray
    Write-Host "  2. 找到 1Panel Client 这个 token" -ForegroundColor Gray
    Write-Host "  3. 点击 Delete 或 Revoke" -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "❌ 推送失败!" -ForegroundColor Red
    Write-Host ""
    Write-Host "可能的原因:" -ForegroundColor White
    Write-Host "  1. 仓库已存在，需要先拉取" -ForegroundColor Gray
    Write-Host "  2. Token 权限不足" -ForegroundColor Gray
    Write-Host "  3. 网络问题" -ForegroundColor Gray
    Write-Host ""
    Write-Host "尝试解决:" -ForegroundColor White
    Write-Host "  git pull origin main --rebase" -ForegroundColor Gray
    Write-Host "  git push origin main" -ForegroundColor Gray
}

Pause
