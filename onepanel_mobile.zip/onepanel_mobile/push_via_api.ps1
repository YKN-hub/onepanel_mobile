# 1Panel Client - GitHub API 推送脚本
# 使用 GitHub REST API 直接推送代码

$ErrorActionPreference = 'Stop'
$host.UI.RawUI.WindowTitle = "1Panel Client - GitHub API 推送"

# 配置
$token = "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"
$username = "YKN-hub"
$repoName = "onepanel_mobile"
$projectDir = "C:\Users\Administrator\codearts\2026-10-19-10-39-29\onepanel_mobile"

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  1Panel Client - GitHub API 推送" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "用户名: $username" -ForegroundColor Cyan
Write-Host "仓库: $repoName" -ForegroundColor Cyan
Write-Host ""

# 检查项目目录
if (-not (Test-Path $projectDir)) {
    Write-Host "❌ 错误: 项目目录不存在" -ForegroundColor Red
    Pause
    exit 1
}

# 创建仓库
Write-Host "[1/4] 创建 GitHub 仓库..." -ForegroundColor White

$headers = @{
    "Authorization" = "token $token"
    "Accept" = "application/vnd.github.v3+json"
}

$repoData = @{
    name = $repoName
    description = "1Panel Client - 1Panel 第三方全平台客户端"
    private = $false
    auto_init = $false
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "https://api.github.com/user/repos" -Method Post -Headers $headers -Body $repoData -ContentType "application/json"
    Write-Host "  ✅ 仓库创建成功: $($response.html_url)" -ForegroundColor Green
} catch {
    if ($_.Exception.Response.StatusCode -eq 422) {
        Write-Host "  ⏭️  仓库已存在，继续..." -ForegroundColor Yellow
    } else {
        Write-Host "  ❌ 创建失败: $($_.Exception.Message)" -ForegroundColor Red
        Pause
        exit 1
    }
}

# 获取默认分支
Write-Host "[2/4] 获取仓库信息..." -ForegroundColor White
try {
    $repoInfo = Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName" -Method Get -Headers $headers
    $defaultBranch = $repoInfo.default_branch
    Write-Host "  默认分支: $defaultBranch" -ForegroundColor Gray
} catch {
    Write-Host "  ❌ 获取失败: $($_.Exception.Message)" -ForegroundColor Red
    Pause
    exit 1
}

# 获取主分支的 tree
Write-Host "[3/4] 准备文件..." -ForegroundColor White

# 获取所有文件
$files = Get-ChildItem -Path $projectDir -Recurse -File | Where-Object {
    $_.FullName -notmatch "\.git" -and
    $_.FullName -notmatch "node_modules" -and
    $_.FullName -notmatch "build" -and
    $_.FullName -notmatch "__pycache__"
}

Write-Host "  找到 $($files.Count) 个文件" -ForegroundColor Gray

# 创建初始 commit
Write-Host "[4/4] 推送文件..." -ForegroundColor White

# 获取主分支的 latest commit
try {
    $latestCommit = Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName/commits/$defaultBranch" -Method Get -Headers $headers
    $baseTreeSha = $latestCommit.commit.tree.sha
    $parentSha = $latestCommit.sha
    Write-Host "  已有提交，准备更新..." -ForegroundColor Yellow
} catch {
    # 如果仓库是空的，创建初始 commit
    $baseTreeSha = $null
    $parentSha = $null
    Write-Host "  空仓库，创建初始提交..." -ForegroundColor Yellow
}

# 创建 tree
$tree = @()

foreach ($file in $files) {
    $relativePath = $file.FullName.Substring($projectDir.Length + 1).Replace("\", "/")
    
    # 跳过一些文件
    if ($relativePath -match "\.git" -or $relativePath -match "node_modules" -or $relativePath -match "build") {
        continue
    }
    
    # 读取文件内容并编码为 base64
    $content = Get-Content -Path $file.FullName -Raw -Encoding UTF8
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
    $base64Content = [Convert]::ToBase64String($bytes)
    
    $tree += @{
        path = $relativePath
        mode = "100644"
        type = "blob"
        content = $content
    }
}

Write-Host "  准备提交 $($tree.Count) 个文件..." -ForegroundColor Gray

# 创建 blob 和 tree
$treeData = @{
    tree = $tree
} | ConvertTo-Json -Depth 10

try {
    $newTree = Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName/git/trees" -Method Post -Headers $headers -Body $treeData -ContentType "application/json"
    Write-Host "  ✅ Tree 创建成功" -ForegroundColor Green
} catch {
    Write-Host "  ❌ Tree 创建失败: $($_.Exception.Message)" -ForegroundColor Red
    Pause
    exit 1
}

# 创建 commit
$commitData = @{
    message = "Initial commit: 1Panel Client iOS app

- 完整仪表盘、服务器、容器、网站、数据库、文件、监控模块
- 60+ 数据模型
- GitHub Actions iOS/Android 构建工作流
- 中英文国际化支持
- 多服务器管理"
    tree = $newTree.sha
} | ConvertTo-Json -Depth 5

if ($parentSha) {
    $commitData | Add-Member -NotePropertyName parents -NotePropertyValue @($parentSha)
}

try {
    $newCommit = Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName/git/commits" -Method Post -Headers $headers -Body ($commitData | ConvertTo-Json -Depth 5) -ContentType "application/json"
    Write-Host "  ✅ Commit 创建成功: $($newCommit.sha)" -ForegroundColor Green
} catch {
    Write-Host "  ❌ Commit 创建失败: $($_.Exception.Message)" -ForegroundColor Red
    Pause
    exit 1
}

# 更新引用
$refData = @{
    sha = $newCommit.sha
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri "https://api.github.com/repos/$username/$repoName/git/refs/heads/$defaultBranch" -Method Patch -Headers $headers -Body $refData -ContentType "application/json" | Out-Null
    Write-Host "  ✅ 引用更新成功" -ForegroundColor Green
} catch {
    Write-Host "  ❌ 引用更新失败: $($_.Exception.Message)" -ForegroundColor Red
    Pause
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  ✅ 推送成功!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "📌 仓库地址: https://github.com/$username/$repoName" -ForegroundColor Cyan
Write-Host ""
Write-Host "🚀 下一步:" -ForegroundColor White
Write-Host "  1. 打开 https://github.com/$username/$repoName" -ForegroundColor Gray
Write-Host "  2. 点击 Actions 标签" -ForegroundColor Gray
Write-Host "  3. 选择 Build iOS 工作流" -ForegroundColor Gray
Write-Host "  4. 点击 Run workflow 触发构建" -ForegroundColor Gray
Write-Host ""
Write-Host "⚠️  安全提醒: 请立即撤销此 Token!" -ForegroundColor Yellow
Write-Host "  1. 打开 https://github.com/settings/tokens" -ForegroundColor Gray
Write-Host "  2. 找到 1Panel Client 这个 token" -ForegroundColor Gray
Write-Host "  3. 点击 Delete 或 Revoke" -ForegroundColor Gray
Write-Host ""

Pause
